
let attempts = 0;
const correctPassword = "KKMN";

function normalize(input) {
    return input.toUpperCase().split('').sort().join('');
}

function checkPassword() {
    const input = document.getElementById("password-input").value;
    const message = document.getElementById("message");

    if (input === correctPassword) {
        document.getElementById("password-screen").style.display = "none";
        document.getElementById("content").style.display = "block";
    } else if (normalize(input) === normalize(correctPassword)) {
        message.textContent = "Çok yaklaştınız.";
        attempts++;
    } else {
        attempts++;
        if (attempts >= 3) {
            message.textContent = "İpucu: Ben-Babam-Annem-Kardeşim";
        } else {
            message.textContent = "Şifre yanlış.";
        }
    }
}
